# -*- coding: utf-8 -*-

from . import inventory_dashboard
